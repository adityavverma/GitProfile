export default [
  { label: 'JavaScript', value: 16, color: '#f1e05a' },
  { label: 'CSS', value: 9, color: '#563d7c' },
  { label: 'HTML', value: 7, color: '#e34c26' },
  { label: 'Vue', value: 5, color: '#2c3e50' },
  { label: 'Others', value: 2, color: '#ccc' },
  { label: 'Shell', value: 2, color: '#89e051' },
];
